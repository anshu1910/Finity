# devbits
1. Frontend is built using HTML,CSS, Javascript with importing the public APIs in the coiner.html page. In total the frontend consists of a landing page, a login/ signup page , 4 different pages for investmnet instruments 
2. Backend pages are built using django, hosted on pythonanywhere.com (https://anjali42.pythonanywhere.com/api/login/) the APIs built are login, logout,change password, signup.
   
